// Copyright 1998-2017 Epic Games, Inc. All Rights Reserved.

#include "Drone_follower.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE(FDefaultGameModuleImpl, Drone_follower, "Drone_follower");

DEFINE_LOG_CATEGORY(LogFlying)
